# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from . import pallet
from . import res_config_settings
from . import stock_quant
from . import stock_move
from . import stock_picking
from . import stock_package_level
from . import barcode
