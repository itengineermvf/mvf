# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, fields


class StockMove(models.Model):
    _inherit = 'stock.move'

    def _prepare_move_line_vals(self, quantity=None, reserved_quant=None):
        vals = super(StockMove, self)._prepare_move_line_vals(quantity=quantity, reserved_quant=reserved_quant)
        if reserved_quant and reserved_quant.package_id\
            and reserved_quant.package_id.pallet_id:
            vals.update({
                'pallet_id': reserved_quant.package_id.pallet_id.id,
                'result_pallet_id': reserved_quant.package_id.pallet_id.id
            })
        return vals


class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    pallet_id = fields.Many2one('stock.pallet.package', 'Source Pallet',
        check_company=True, domain="[('location_id', '=', location_id)]")
    result_pallet_id = fields.Many2one('stock.pallet.package', 'Destination Pallet', check_company=True,
        domain="['|', '|', ('location_id', '=', False), ('location_id', '=', location_dest_id), ('id', '=', pallet_id)]",
        help="If set, the package are packed into this pallet")
