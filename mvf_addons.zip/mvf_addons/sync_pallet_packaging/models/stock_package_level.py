# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, fields


class StockPackageLevel(models.Model):
    _inherit = 'stock.package_level'

    pallet_id = fields.Many2one('stock.pallet.package', 'Pallet', related="package_id.pallet_id", store=True, readonly=True)
