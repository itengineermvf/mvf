# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, fields


class QuantPackage(models.Model):
    _inherit = 'stock.quant.package'

    pallet_id = fields.Many2one('stock.pallet.package', string="Pallet", copy=False,
                    domain="[('location_id', '=', location_id)]")
