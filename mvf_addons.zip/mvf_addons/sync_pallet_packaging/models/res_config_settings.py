# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    group_stock_pallet_package = fields.Boolean(string='Inventory Pallet', implied_group='sync_pallet_packaging.group_stock_pallet_package')
