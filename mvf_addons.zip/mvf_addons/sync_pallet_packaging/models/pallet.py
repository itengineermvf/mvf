# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import api, fields, models, _


class StockPalletPackage(models.Model):
    _name = "stock.pallet.package"
    _description = "Stock Pallet Package"
    _order = 'name'

    _sql_constraints = [
        ('name_company_uniq', 'unique (name, company_id)', 'The name of the pallet must be unique per company !'),
    ]

    @api.depends('package_ids.pallet_id', 'package_ids.location_id', 'package_ids.company_id', 'package_ids.owner_id')
    def _compute_pallet_info(self):
        for pallet in self:
            values = {'location_id': False, 'owner_id': False}
            if pallet.package_ids:
                values['location_id'] = pallet.package_ids[0].location_id
                if all(q.owner_id == pallet.package_ids[0].owner_id for q in pallet.package_ids):
                    values['owner_id'] = pallet.package_ids[0].owner_id
                if all(q.company_id == pallet.package_ids[0].company_id for q in pallet.package_ids):
                    values['company_id'] = pallet.package_ids[0].company_id
            pallet.location_id = values['location_id']
            pallet.company_id = values.get('company_id')
            pallet.owner_id = values['owner_id']

    name = fields.Char('Pallet Reference', copy=False, index=True, required=True,
        default=lambda self: self.env['ir.sequence'].next_by_code('stock.pallet.package') or _('Unknown Pallet'))
    package_ids = fields.One2many('stock.quant.package', 'pallet_id', 'Bulk Package', readonly=True)
    location_id = fields.Many2one('stock.location', 'Location', index=True, compute='_compute_pallet_info', store=True, readonly=True)
    company_id = fields.Many2one('res.company', 'Company', index=True, default=lambda self: self.env.company,
                                            compute='_compute_pallet_info', store=True, readonly=True)
    owner_id = fields.Many2one('res.partner', 'Owner', index=True, default=lambda self: self.env.user.partner_id,
                                    compute='_compute_pallet_info', store=True, readonly=True)

    def action_view_picking(self):
        action = self.env.ref('stock.action_picking_tree_all').read()[0]
        domain = ['|', ('result_pallet_id', 'in', self.ids), ('pallet_id', 'in', self.ids)]
        pickings = self.env['stock.move.line'].search(domain).mapped('picking_id')
        action['domain'] = [('id', 'in', pickings.ids)]
        return action

    def unpack_pallet(self):
        for pallet in self:
            move_line_to_modify = self.env['stock.move.line'].search([
                ('pallet_id', '=', pallet.id),
                ('state', 'in', ('assigned', 'partially_available')),
                ('product_qty', '!=', 0),
            ])
            move_line_to_modify.write({'pallet_id': False})
            pallet.mapped('package_ids').sudo().write({'pallet_id': False})
