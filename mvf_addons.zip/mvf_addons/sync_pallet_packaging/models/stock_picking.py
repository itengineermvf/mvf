# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, fields, _
from odoo.tools import float_compare
from odoo.exceptions import UserError


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def _compute_has_pallets(self):
        for picking in self:
            picking.has_pallets = False
            if any(picking.move_line_ids.filtered(lambda ml: ml.result_pallet_id)):
                picking.has_pallets = True

    has_pallets = fields.Boolean('Has Pallets', compute='_compute_has_pallets', help='Check the existence of destination pallet on move lines')
    scanned_pallet_ids = fields.Many2many('stock.pallet.package', string='Scanned Pallets', copy=False)

    def action_see_pallets(self):
        self.ensure_one()
        action = self.env.ref('sync_pallet_packaging.action_stock_pallet_package_view').read()[0]
        pallets = self.move_line_ids.mapped('result_pallet_id')
        action['domain'] = [('id', 'in', pallets.ids)]
        action['context'] = {'picking_id': self.id}
        return action

    def action_done(self):
        picking_move_lines = self.move_line_ids
        if (not self.picking_type_id.show_reserved and not self.env.context.get('barcode_view')):
            picking_move_lines = self.move_line_nosuggest_ids

        for move_line in picking_move_lines.filtered(lambda ml: ml.result_pallet_id and ml.result_package_id):
            move_line.result_package_id.pallet_id = move_line.result_pallet_id.id
        return super(StockPicking, self).action_done()

    def put_in_pallet(self):
        self.ensure_one()
        if self.state not in ('done', 'cancel'):
            picking_move_lines = self.move_line_ids
            if (not self.picking_type_id.show_reserved and not self.env.context.get('barcode_view')):
                picking_move_lines = self.move_line_nosuggest_ids

            move_line_ids = picking_move_lines.filtered(lambda ml:
                float_compare(ml.qty_done, 0.0, precision_rounding=ml.product_uom_id.rounding) > 0
                and ml.result_package_id and not ml.result_pallet_id
            )
            if not move_line_ids:
                move_line_ids = picking_move_lines.filtered(lambda ml: float_compare(ml.product_uom_qty, 0.0,
                                     precision_rounding=ml.product_uom_id.rounding) > 0 and float_compare(ml.qty_done, 0.0,
                                     precision_rounding=ml.product_uom_id.rounding) == 0 and ml.result_package_id and not ml.result_pallet_id)
            if move_line_ids:
                res = self._put_in_pallet(move_line_ids)
            else:
                raise UserError(_("Please add 'Done' qantitites to the picking and create a new pack first."))

    def _put_in_pallet(self, move_line_ids):
        pallet = False
        for pick in self:
            move_lines_to_pallet = self.env['stock.move.line']
            pallet = self.env['stock.pallet.package'].create({'owner_id': self.env.user.partner_id.id})

            for ml in move_line_ids.filtered(lambda m: m.result_package_id and not m.result_pallet_id):
                move_lines_to_pallet += ml
                if ml.package_level_id:
                    ml.package_level_id.pallet_id = pallet.id
            move_lines_to_pallet.write({
                'result_pallet_id': pallet.id,
            })
        return pallet

    def _add_move_lines(self, package):
        quant_fields = lambda model: self.env[model]._fields
        if 'scanned_package_ids' in quant_fields('stock.picking'):
            self.update({
                'scanned_package_ids': [(4, package.id)]
            })
        for quant in package.quant_ids:
            picking_move_lines = self.move_line_ids_without_package
            if not self.show_reserved:
                picking_move_lines = self.move_line_nosuggest_ids

            new_move_line = self.move_line_ids.new({
                'product_id': quant.product_id.id,
                'product_uom_id': quant.product_id.uom_id.id,
                'location_id': self.location_id.id,
                'location_dest_id': self.location_dest_id.id,
                'display_name': quant.product_id.display_name,
                'qty_done': quant.quantity,
                'product_uom_qty': 0.0,
                'date': fields.datetime.now(),
                'package_id': package.id,
                'result_package_id': package.id,
                'pallet_id': package.pallet_id.id,
                'result_pallet_id': package.pallet_id.id,
                'state': 'assigned',
                'lot_id': quant.lot_id.id
            })
            if self.show_reserved:
                self.move_line_ids_without_package += new_move_line
            else:
                self.move_line_nosuggest_ids += new_move_line

    def _create_pallet_source(self, pallet_source):
        for package in pallet_source.package_ids:
            self._add_move_lines(package)
        return True

    def on_barcode_scanned(self, barcode):
        if not self.env.company.nomenclature_id:
            # Logic for pallet in source location
            pallet_source = self.env['stock.pallet.package'].search([('name', '=', barcode), ('location_id', 'child_of', self.location_id.id)], limit=1)
            if pallet_source and pallet_source.id in self.scanned_pallet_ids.ids:
                return {'warning': {
                    'title': _('Already Scanned'),
                    'message': _('The barcode pallet "%(barcode)s" is already scanned.') % {'barcode': barcode}
                }}

            move_lines = self.mapped('move_line_ids').filtered(lambda ml: ml.state in ('confirmed', 'partially_available', 'assigned')\
                                and ml.result_pallet_id.name == barcode)
            if move_lines and self.picking_type_id.code == 'internal':
                for line in move_lines:
                    line.qty_done = line.product_uom_qty
                return

            if pallet_source and pallet_source.id not in self.scanned_pallet_ids.ids:
                self.update({
                    'scanned_pallet_ids': [(4, pallet_source.id)]
                })
                self._create_pallet_source(pallet_source)
                return
        else:
            parsed_result = self.env.company.nomenclature_id.parse_barcode(barcode)

            if parsed_result['type'] == 'pallet':
                pallet_source = self.env['stock.pallet.package'].search([('name', '=', parsed_result['code']), ('location_id', 'child_of', self.location_id.id)], limit=1)
                if pallet_source and pallet_source.id in self.scanned_pallet_ids.ids:
                    return {'warning': {
                        'title': _('Already Scanned'),
                        'message': _('The barcode pallet "%(barcode)s" is already scanned.') % {'barcode': barcode}
                    }}

                move_lines = self.mapped('move_line_ids').filtered(lambda ml: ml.state in ('confirmed', 'partially_available', 'assigned')\
                                and ml.result_pallet_id.name == barcode)
                if move_lines and self.picking_type_id.code == 'internal':
                    for line in move_lines:
                        line.qty_done = line.product_uom_qty
                    return

                if pallet_source and pallet_source.id not in self.scanned_pallet_ids.ids:
                    self.update({
                        'scanned_pallet_ids': [(4, pallet_source.id)]
                    })
                    self._create_pallet_source(pallet_source)
                    return
        return super(StockPicking, self).on_barcode_scanned(barcode)
