# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

{
    'name': 'Inventory Product Packaging Type Pallet',
    'version': '1.0',
    'author': 'Synconics Technologies Pvt. Ltd',
    'website': 'https://www.synconics.com',
    'category': 'Operations/Inventory',
    'sequence': 15,
    'summary': 'On Inventory Product Packaging Type Pallet Flow.',
    'depends': ['stock', 'stock_barcode'],
    'description': """
On Inventory Product Packaging Type Pallet flow.
    """,
    'data': [
        'security/ir.model.access.csv',
        'security/pallet_security.xml',
        'data/pallet_sequence_data.xml',
        'data/default_barcode_patterns.xml',
        'views/res_config_settings_view.xml',
        'views/pallet_view.xml',
        'views/stock_quant_view.xml',
        'views/stock_move_line_view.xml',
        'views/stock_picking_view.xml',
        'views/stock_package_level_view.xml',
        'report/pallet_barcode_report.xml',
        'report/pallet_report_views.xml'
    ],
    'demo': [],
    'license': 'OPL-1',
    'installable': True,
    'auto_install': False,
}
