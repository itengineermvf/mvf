# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, _
from odoo.exceptions import UserError


class IrAttachment(models.Model):
    _inherit = "ir.attachment"

    def unlink(self):
        for attachment in self.filtered(lambda a: a.res_model == 'product.product' or a.res_model == 'product.template'):
            if not self.user_has_groups('mvf_customization.group_general_manager'):
                raise UserError(_("You can not delete product attachment only 'General Manager' can delete product attachment."))
        return super(IrAttachment, self).unlink()
