# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class StockQuantPackage(models.Model):
    _inherit = "stock.quant.package"

    @api.constrains('name')
    def _validate_package_name(self):
        for record in self:
            if any(self.search([('name', '=', record.name), ('id', '!=', record.id)])):
                raise ValidationError(_('The name of the package must be unique.'))
