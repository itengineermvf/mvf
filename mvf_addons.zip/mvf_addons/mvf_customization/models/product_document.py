# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class ProductDocument(models.Model):
    """ Extension of documents.document only used in MRP to handle archivage
    and basic versioning.
    """
    _name = 'product.document'
    _description = "Product Document"
    _inherits = {'documents.document': 'document_id',}
    # _order = "priority desc, id desc"

    @api.model
    def default_get(self, default_fields):
        res = super(ProductDocument, self).default_get(default_fields)
        product_folder = self.env.company.product_folder
        if not product_folder:
            product_folder = self.env.ref('documents_product.documents_product_folder', raise_if_not_found=False)
        res.update({'folder_id': product_folder.id})
        return res

    document_id = fields.Many2one(comodel_name='documents.document', string='Related Document', required=True, ondelete='cascade')
    ir_attachment_id = fields.Many2one(comodel_name='ir.attachment', related='document_id.attachment_id', readonly=True, string='Related attachment')
    active = fields.Boolean('Active', default=True)
    dtype = fields.Selection([
        ('0', "Product Specification/Catalog"),
        ('1', "MSDS"),
        ('2', "Customer Drawing / Supplier Drawing"),
        ('3', "MVF Drawing (PDF)"),
        ('4', "MVF Drawing (DWG or IGS or STP file)")], string="Document Type", help='List of related product documents.', default='0')
    product_id = fields.Many2one(comodel_name='product.product', string="Product")

    @api.model
    def create(self, vals):
        vals.update(
            res_id=vals.get('product_id', vals.get('res_id', 0)),
            res_model=self.product_id._name or 'product.product',
        )
        return super(ProductDocument, self).create(vals)

    def unlink(self):
        self.filtered(lambda doc: doc.ir_attachment_id).mapped('ir_attachment_id').unlink()
        return super(ProductDocument, self).unlink()


class Documents(models.Model):
    _inherit = "documents.document"

    def unlink(self):
        if not self.user_has_groups('mvf_customization.group_general_manager'):
            raise UserError(_("Only 'General Manager' can delete this Document."))
        return super(Documents, self).unlink()
