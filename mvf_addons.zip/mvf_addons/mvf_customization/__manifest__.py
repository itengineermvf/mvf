# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

{
    'name' : 'MVF Customization',
    'version' : '1.0',
    'summary': 'MVF Customization',
    'description': """ MVF Customization """,
    'category': 'tools',
    'author': "Synconics Technologies Pvt. Ltd.",
    'website': "https://www.synconics.com",
    'depends' : ['documents_product', 'sale', 'stock'],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/product_views.xml',
        'views/product_document_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
