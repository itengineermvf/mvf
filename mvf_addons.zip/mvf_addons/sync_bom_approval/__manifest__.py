# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

{
    'name': 'Manufacturing Bom Approval flow',
    'version': '1.0',
    'author': 'Synconics Technologies Pvt. Ltd',
    'website': 'https://www.synconics.com',
    'category': 'Manufacturing',
    'sequence': 15,
    'summary': 'On Bill of Material add Approval flow.',
    'depends': ['mrp'],
    'description': """
Manage Bom (Bill of Material) using Approval flow.
    """,
    'data': [
        'security/bom_security.xml',
        'views/assets.xml',
        'views/mrp_bom_view.xml',
        'views/res_config_settings_view.xml'
    ],
    'demo': [],
    'license': 'OPL-1',
    'installable': True,
    'auto_install': False,
}
