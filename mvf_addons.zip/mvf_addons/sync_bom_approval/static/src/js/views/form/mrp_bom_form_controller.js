odoo.define('sync_bom_approval.MrpBomFormController', function (require) {
"use strict";

var FormController = require('web.FormController');
var Dialog = require('web.Dialog');

var core = require('web.core');
var _t = core._t;


var MrpBomFormController = FormController.extend({

    _hasApproved: function(recordID) {
        var record = this.model.get(recordID || this.handle, { raw: true });
        if (!_.isNull(record) && record.data && _.has(record.data, 'state')) {
            return record.data.state === "approved";
        } else { return false; };
    },

    _onEdit: function () {
        if (this._hasApproved()) {
            return Dialog.alert(this, _t("You can\'t update after approved!"), {
                title: _t('BOM approved'),
            });
        };
        this._super.apply(this, arguments);
    },

    _setMode: function (mode, recordID) {
        const isApproved = this._hasApproved(recordID);
        mode = isApproved ? 'readonly' : mode;
        return this._super(mode, recordID);
    },

    _saveRecord: function (recordID, options) {
        var self = this;
        return this._super.apply(this, arguments).then(function(changedFields) {
            self._setMode('readonly');
            return changedFields;
        });
    },

    on_attach_callback: function () {
        this._super.apply(this, arguments);
        const isApproved = this._hasApproved();
    },

});

return MrpBomFormController;

});

