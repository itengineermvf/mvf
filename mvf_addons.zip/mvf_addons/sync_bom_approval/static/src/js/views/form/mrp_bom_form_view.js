odoo.define('event.MrpBomFormView', function (require) {
"use strict";

var FormView = require('web.FormView');
var MrpBomFormController = require('sync_bom_approval.MrpBomFormController');
var viewRegistry = require('web.view_registry');

var MrpBomFormView = FormView.extend({
    config: _.extend({}, FormView.prototype.config, {
        Controller: MrpBomFormController
    }),
});

viewRegistry.add('bom_approval_form', MrpBomFormView);

return MrpBomFormView;

});
