# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    group_mrp_bom_approval = fields.Boolean(string='BOM Approval', implied_group='sync_bom_approval.group_mrp_bom_approval')
