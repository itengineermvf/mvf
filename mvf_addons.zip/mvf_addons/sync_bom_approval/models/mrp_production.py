# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, fields


class MrpProduction(models.Model):
    _inherit = 'mrp.production'

    bom_id = fields.Many2one(
        'mrp.bom', 'Bill of Material',
        readonly=True, states={'draft': [('readonly', False)]},
        domain="""[
        '&',
            '&',
                '|',
                    ('company_id', '=', False),
                    ('company_id', '=', company_id),
                '&',
                    '|',
                        ('product_id','=',product_id),
                        '&',
                            ('product_tmpl_id.product_variant_ids','=',product_id),
                            ('product_id','=',False),
            ('type', '=', 'normal'),
        ('state', '=', 'approved')]""", check_company=True,
        help="Bill of Materials allow you to define the list of required components to make a finished product.")
