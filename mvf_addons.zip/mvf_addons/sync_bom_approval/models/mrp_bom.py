# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, api, fields, _
from odoo.exceptions import UserError


class MrpBom(models.Model):
    _inherit = 'mrp.bom'

    state = fields.Selection([('draft', 'Draft'),
                              ('approved', 'Approved')], string='Status',
                    required=True, readonly=True, copy=False, default='draft', index=True, tracking=True)
    approved_by_user_id = fields.Many2one('res.users', string="Approved By", copy=False)

    @api.model
    def _bom_find_domain(self, product_tmpl=None, product=None, picking_type=None, company_id=False, bom_type=False):
        domain = super(MrpBom, self)._bom_find_domain(product_tmpl=product_tmpl, product=product, picking_type=picking_type,
                                                        company_id=company_id, bom_type=bom_type)
        domain += [('state', '=', 'approved')]
        return domain

    def action_approve(self):
        self.ensure_one()
        if self.create_uid.id == self.env.user.id:
            raise UserError(_("You can not approve this 'Bill of Material'."))
        self.write({
            'state': 'approved',
            'approved_by_user_id': self.env.user.id
        })
        return True

    # def action_draft(self):
    #     self.ensure_one()
    #     self.write({
    #         'state': 'draft',
    #         'approved_by_user_id': False
    #     })
    #     return True
