# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, fields


class MrpUnbuild(models.Model):
    _inherit = 'mrp.unbuild'

    bom_id = fields.Many2one(
        'mrp.bom', 'Bill of Material',
        domain="""[
        '|',
            ('product_id', '=', product_id),
            '&',
                ('product_tmpl_id.product_variant_ids', '=', product_id),
                ('product_id','=',False),
        ('type', '=', 'normal'),
        ('state', '=', 'approved'),
        '|',
            ('company_id', '=', company_id),
            ('company_id', '=', False)
        ]
    """, required=True, states={'done': [('readonly', True)]}, check_company=True)
