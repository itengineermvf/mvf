# -*- coding: utf-8 -*-
{
    'name': "MVF Custom Reports",

    'summary': """
        MVF Custom Reports
    """,

    'description': """
        MVF Custom Reports.
    """,

    'author': "Synconics Technologies Pvt. Ltd.",
    'website': "https://www.synconics.com",
    'category': 'tools',
    'version': '1.4',
    'depends': ["stock", "mvf_package_label", "stock_barcode"],
    'data': [
        "views/report_product_seal.xml",
        "views/report_product_barcode.xml",
        "views/package_product_barcode.xml",
        "views/report_product_label.xml",
        "views/report_delivery_order_packing_list.xml",
        "views/stock_picking_view.xml",
        "views/location_location_view.xml",
        "wizard/product_seal_report_approval_view.xml",
        "security/ir.model.access.csv"
    ],
    'qweb': [],
    'demo': [],
}
