# -*- coding: utf-8 -*-

from odoo import api, models, fields, _
from odoo.exceptions import Warning


class ProductSealReport(models.AbstractModel):
    _name = 'report.mvf_custom_reports.report_product_seal'
    _description = 'Product Seal Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        picking = self.env["stock.picking"].browse(docids)
        package_list = list(set(picking.move_line_ids_without_package.mapped("result_package_id").mapped("name")))
        if len(package_list) == 0:
            raise Warning("There is no package in transfer lines to print a seal.")
        return {
            'doc_ids': docids,
            'doc_model': 'stock.picking',
            'docs': self.env['stock.picking'].browse(docids),
            'report_type': data.get('report_type') if data else '',
            'data': package_list
        }
