# -*- coding: utf-8 -*-

from odoo import api, models, fields, _
from odoo.exceptions import Warning


class DeliveryOrderPackingListReport(models.AbstractModel):
    _name = 'report.mvf_custom_reports.report_delivery_order_packing_list'
    _description = 'Delivery Order Packing List Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        picking = self.env["stock.picking"].browse(docids)
        if picking.picking_type_code != 'outgoing':
            raise Warning("DO Packing List report can be printed from Delivery Orders only.")
        packages = picking.move_line_ids_without_package.mapped("result_package_id")
        if len(packages) == 0:
            raise Warning("There is no package in transfer lines to print Package List.")

        addresses = picking.partner_id.child_ids.filtered(lambda address: address.type == "delivery")
        ship_to_address = addresses and addresses[0] or picking.partner_id
        report_data = {"package_list": packages}
        report_data.update({"total_packages": len(packages.ids)})
        report_data.update({"total_qty": round(sum(picking.move_line_ids_without_package.mapped("qty_done")), 2)})
        report_data.update({"ship_to_address": ship_to_address})
        return {
            'doc_ids': docids,
            'doc_model': 'stock.picking',
            'docs': self.env['stock.picking'].browse(docids),
            'report_type': data.get('report_type') if data else '',
            'data': report_data
        }
