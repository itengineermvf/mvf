# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import Warning


class ProductSealReportApproval(models.TransientModel):
    _name = "product.seal.report.approval"
    _description = "Product Seal Report Approval"

    user_id = fields.Many2one("res.users", "User", help="Inventory Manager for Product Seal Report Approval.")
    password = fields.Char("Password", help="Selected User's Password.")
    picking_id = fields.Many2one("stock.picking", required=True)

    def action_approve(self):
        res = self.env.user._login(self._cr.dbname, self.user_id.login, self.password)
        if res:
            user = self.env["res.users"].browse(res)
            self.user_id = False
            self.password = ""
            return self.picking_id.with_context({"approval_process": True}).print_product_seal()
        else:
            raise Warning("Access Denied!")

    @api.model
    def default_get(self, fields):
        result = super(ProductSealReportApproval, self).default_get(fields)
        if self._context.get('active_id', False) and fields:
            result['picking_id'] = self._context.get('active_id')
        return result
