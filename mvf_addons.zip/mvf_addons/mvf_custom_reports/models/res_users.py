# -*- coding: utf-8 -*-

from odoo import api, models, fields, _


class ResUsers(models.Model):
    _inherit = "res.users"

    @api.model
    def name_search(self, name, args, operator='ilike', limit=100):
        if self._context.get('mvf_inventory_managers_only', False):
            inventory_manager_group = self.env.ref('stock.group_stock_manager')
            if inventory_manager_group:
                args.append(("id", "in", inventory_manager_group.users.ids))
            else:
                args.append(('id', '=', []))
        return super(ResUsers, self).name_search(name, args=args, operator=operator, limit=limit)
