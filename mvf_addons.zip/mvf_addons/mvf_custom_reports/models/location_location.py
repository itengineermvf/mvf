# -*- coding: utf-8 -*-

from odoo import api, models, fields, _


class Location(models.Model):
    _name = "location.location"
    _description = "Locations, Stations and Receiving Points."

    name = fields.Char("Location", required=True, copy=False, help="Location Name.")
    type = fields.Selection([("location", "Location"),
                             ("station", "Station"),
                             ("receiving_point", "Receiving Point")], "Type", default="location", required=True)
