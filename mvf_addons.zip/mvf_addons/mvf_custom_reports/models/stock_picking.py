# -*- coding: utf-8 -*-

import xlsxwriter
import base64

from io import BytesIO

from odoo import api, models, fields, _
from odoo.exceptions import Warning


class StockPicking(models.Model):
    _inherit = "stock.picking"

    product_location_id = fields.Many2one("location.location", "Location", help="Product's Location.")
    receiving_point_id = fields.Many2one("location.location", "Receiving Point", help="Related Receiving Point.")
    station_id = fields.Many2one("location.location", "Station", help="Related Station.")
    product_seal_print_count = fields.Integer("Product Seal Print Count", copy=False, default=0,
                                              help="Counter to maintain print counts.")
    remarks = fields.Char("Remarks", copy=False, help="Remarks.")
    scanned_package_ids = fields.Many2many('stock.quant.package', string='Scanned Packages', copy=False)

    # def action_assign(self):
    #     res = super(StockPicking, self).action_assign()
    #     move_lines = self.mapped('move_line_ids').filtered(lambda move_line: move_line.state in ('confirmed', 'partially_available', 'assigned'))
    #     for line in move_lines:
    #         line.qty_done = line.product_uom_qty
    #     return res

    def _create_package_moves(self, package_source):
        quant_fields = lambda model: self.env[model]._fields
        if 'scanned_pallet_ids' in quant_fields('stock.picking'):
            self.update({
                'scanned_pallet_ids': [(4, package_source.pallet_id.id)]
            })
        for quant in package_source.quant_ids:
            picking_move_lines = self.move_line_ids_without_package
            if not self.show_reserved:
                picking_move_lines = self.move_line_nosuggest_ids
            move_line_vals = {
                'product_id': quant.product_id.id,
                'product_uom_id': quant.product_id.uom_id.id,
                'location_id': self.location_id.id,
                'location_dest_id': self.location_dest_id.id,
                'display_name': quant.product_id.display_name,
                'qty_done': quant.quantity,
                'product_uom_qty': 0.0,
                'date': fields.datetime.now(),
                'package_id': package_source.id,
                'result_package_id': package_source.id,
                'state': 'assigned',
                'lot_id': quant.lot_id.id
            }

            if 'pallet_id' in quant_fields('stock.quant.package'):
                move_line_vals.update({
                    'pallet_id': package_source.pallet_id.id,
                    'result_pallet_id': package_source.pallet_id.id
                })
            new_move_line = self.move_line_ids.new(move_line_vals)
            if self.show_reserved:
                self.move_line_ids_without_package += new_move_line
            else:
                self.move_line_nosuggest_ids += new_move_line
        return True

    def on_barcode_scanned(self, barcode):
        if not self.env.company.nomenclature_id:
            # Logic for packages in source location
            package_source = self.env['stock.quant.package'].search([('name', '=', barcode), ('location_id', 'child_of', self.location_id.id)], limit=1)
            if package_source and package_source.id in self.scanned_package_ids.ids:
                return {'warning': {
                    'title': _('Already Scanned'),
                    'message': _('The barcode package "%(barcode)s" is already scanned.') % {'barcode': barcode}
                }}
            if package_source and package_source.id not in self.scanned_package_ids.ids:
                self.update({
                    'scanned_package_ids': [(4, package_source.id)]
                })
                self._create_package_moves(package_source)
                return
        else:
            parsed_result = self.env.company.nomenclature_id.parse_barcode(barcode)

            if parsed_result['type'] == 'package':
                package_source = self.env['stock.quant.package'].search([('name', '=', parsed_result['code']), ('location_id', 'child_of', self.location_id.id)], limit=1)
                if package_source and package_source.id in self.scanned_package_ids.ids:
                    return {'warning': {
                        'title': _('Already Scanned'),
                        'message': _('The barcode package "%(barcode)s" is already scanned.') % {'barcode': barcode}
                    }}
                if package_source and package_source.id not in self.scanned_package_ids.ids:
                    self.update({
                        'scanned_package_ids': [(4, package_source.id)]
                    })
                    self._create_package_moves(package_source)
                    return
        return super(StockPicking, self).on_barcode_scanned(barcode)

    def print_product_seal(self):
        if self.product_seal_print_count < 2 or self._context.get("approval_process", False):
            self.product_seal_print_count += 1
            return self.env.ref('mvf_custom_reports.action_report_product_seal').report_action(self)
        else:
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'product.seal.report.approval',
                'view_mode': 'form',
                'view_id': self.env.ref("mvf_custom_reports.print_seal_report_approval_form").id,
                'target': 'new',
            }

    def print_serial_no_report(self):
        filename = 'Serial Number Report.xlsx'
        fp = BytesIO()

        report_data, max_product_len_in_a_package, max_len_box_header, max_len_product_header = self.get_serial_no_report_data()

        workbook = xlsxwriter.Workbook(fp)
        heading = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'border': 2})
        box_serial_no = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'left': 2, 'top':1, 'right': 2, 'bottom':1})
        last_box_serial_no = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'left': 2, 'top': 1, 'right': 2, 'bottom': 2})
        product_serial_no = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'left': 1, 'top': 1, 'right': 1, 'bottom': 1})
        last_product_serial_no_bottom = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'left': 1, 'top': 1, 'right': 1, 'bottom': 2})
        last_product_serial_no_right = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'left': 1, 'top': 1, 'right': 2, 'bottom': 1})
        last_product_serial_no_bottom_right = workbook.add_format({'align': 'center', 'valign': 'vcenter', 'left': 1, 'top': 1, 'right': 2, 'bottom': 2})

        sheet = workbook.add_worksheet('Serial Numbers')
        sheet.write(0, 0, "Returnable Box Serial No", heading)
        if max_product_len_in_a_package > 1:
            sheet.merge_range(0, 1, 0, max_product_len_in_a_package, "Product Serial No", heading)
        else:
            sheet.write(0, 1, "Product Serial No", heading)
        sheet.set_column(0, 0, max_len_box_header+2)
        for index in range(max_product_len_in_a_package):
            if index+1 > max_product_len_in_a_package:
                break
            sheet.set_column(1, index+1, max_len_product_header)
        row = 1
        for package_no, serial_no_list in report_data.items():
            box_serial_no_format = box_serial_no
            if row == len(list(report_data.keys())):
                box_serial_no_format = last_box_serial_no
            sheet.write(row, 0, package_no, box_serial_no_format)
            col = 1
            for serial_no in serial_no_list:
                product_serial_no_format = product_serial_no
                if col == max_product_len_in_a_package and row != len(list(report_data.keys())):
                    product_serial_no_format = last_product_serial_no_right
                elif col != max_product_len_in_a_package and row == len(list(report_data.keys())):
                    product_serial_no_format = last_product_serial_no_bottom
                elif col == max_product_len_in_a_package and row == len(list(report_data.keys())):
                    product_serial_no_format = last_product_serial_no_bottom_right

                sheet.write(row, col, serial_no, product_serial_no_format)
                col += 1
                if col > len(serial_no_list) and len(serial_no_list) < max_product_len_in_a_package:
                    for new_col in range(col, max_product_len_in_a_package):
                        if row == len(list(report_data.keys())):
                            sheet.write(row, new_col, "", last_product_serial_no_bottom)
                    if row == len(list(report_data.keys())):
                        sheet.write(row, max_product_len_in_a_package, "", last_product_serial_no_bottom_right)
                    else:
                        sheet.write(row, max_product_len_in_a_package, "", last_product_serial_no_right)
            row += 1
        workbook.close()
        file_save = base64.encodestring(fp.getvalue())
        fp.close()
        attachment_id = self.env['ir.attachment'].create({'name': filename,
                                                          'datas': file_save,
                                                          'res_model': 'stock.picking',
                                                          'res_id': self.id,
                                                          'type': 'binary',
                                                          })
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/%s?download=true' % (attachment_id.id),
            'target': 'self',
            'nodestroy': False,
        }

    def get_serial_no_report_data(self):
        report_data = {}
        max_product_len_in_a_package = 0
        max_len_box_header = len("Returnable Box Serial No")
        max_len_product_header = len("Product Serial No")

        if not self.move_line_ids_without_package.mapped("result_package_id"):
            raise Warning("No Packages to generate Serial Number List Report.")
        for move in self.move_line_ids_without_package:
            if move.result_package_id:
                if max_len_box_header < len(move.result_package_id.name):
                    max_len_box_header = len(move.result_package_id.name)
                tmp_data = report_data.get(move.result_package_id.name, False)
                if move.lot_id:
                    if tmp_data:
                        tmp_data.append(move.lot_id.name)
                        if len(tmp_data) > max_product_len_in_a_package:
                            max_product_len_in_a_package = len(tmp_data)
                        if max_len_product_header < len(move.lot_id.name):
                            max_len_product_header = len(move.lot_id.name)
                        report_data.update({move.result_package_id.name: tmp_data})
                    else:
                        report_data.update({move.result_package_id.name: [move.lot_id.name]})
                        if max_product_len_in_a_package == 0:
                            max_product_len_in_a_package = 1
                        if max_len_product_header < len(move.lot_id.name):
                            max_len_product_header = len(move.lot_id.name)
        return report_data, max_product_len_in_a_package, max_len_box_header, max_len_product_header

