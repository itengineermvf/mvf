# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import quality_control_point
from . import quality_inspection
from . import quality_alert
from . import quality_inspection_stock_picking
from . import product
from . import res_config_settings
