# -*- coding: utf-8 -*-
# Part of Odoo. See COPYRIGHT & LICENSE files for full copyright and licensing details.

from odoo import models, fields, api


class QCPChecklist(models.TransientModel):
    _name = "qcp.checklist"
    _description = "QCP Checklist"

    @api.model
    def default_get(self, fields):
        rec = super(QCPChecklist, self).default_get(fields)
        context = dict(self.env.context) or {}
        if context.get('active_model') == 'quality.inspection.line' and context.get('active_id'):
            inspection_line_id = self.env['quality.inspection.line'].browse(context['active_id'])
            rec.update({
                'inspection_line_id': inspection_line_id.id,
                'control_point_line_checkboxs_ids': inspection_line_id.control_point_line_checkboxs_ids.ids
            })
        return rec

    inspection_line_id = fields.Many2one('quality.inspection.line', string='Inspection')
    control_point_line_id = fields.Many2one('quality.control.point.line', related="inspection_line_id.control_point_line_id", store=True)
    control_point_line_checkboxs_ids = fields.Many2many('quality.control.point.line.checkboxs',
                                                domain="[('control_point_line_id', '=', control_point_line_id)]", string="QCP Checklist")
    is_checklist_editable = fields.Boolean(related="control_point_line_id.is_checklist_editable")

    def save_checklist(self):
        self.ensure_one()
        if self.inspection_line_id:
            self.inspection_line_id.control_point_line_checkboxs_ids = [(6, 0, self.control_point_line_checkboxs_ids.ids or [])]
        return self.cancel_checklist()

    def cancel_checklist(self):
        self.ensure_one()
        action = self.env.ref('sync_quality_control.quality_inspection_action_small').read()[0]
        action['context'] = dict(self.env.context)
        action['res_id'] = self.inspection_line_id and self.inspection_line_id.quality_inspection_id.id
        return action
