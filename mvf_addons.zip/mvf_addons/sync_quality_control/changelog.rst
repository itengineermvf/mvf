============
[1.1]
[ADD] Added dynamic selection for report printing file extension settings.
[ADD] Added restrict validation flow for PO

============
[1.1.1]
[UPDATE] Update quality control alert view

============
[1.1.2]
[FIX] Serial/Lot number related bug at the time of quality inspection.

============
[1.1.3]
[FIX] Validate measure inspection point related bug at the time of quality inspection.

============
[1.1.4]
[FIX] Open quality inspections wizard open related bug.

============
[1.1.5]
[UPDATE] Set company id false in sequence code for multi company flow.

============
[1.1.6]
[ADD] Added check quality inspections by detailed operations wise.

============
[1.1.7]
[ADD] Added add notes wizard in quality inspection.

============
[1.1.8]
[ADD] Added automatic generate alert based on configuration.
[ADD] Special permission for pass or fail quality inspection.

============
[1.1.9]
[ADD] Added notes on inspection wizard.

============
[1.2.0]
[SOLVE] multi company issue in quality alert.
